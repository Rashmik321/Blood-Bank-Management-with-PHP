<footer class="footer text-center bg-light">
	© Copyright <span id="demo"></span> <span class="brand">Blood Bank System by GPW. </span> All Rights Reserved.
	<script>
		date = new Date();
    	document.getElementById("demo").innerHTML=date.getFullYear();
    </script>
</footer>
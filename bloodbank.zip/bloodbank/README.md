# online_bloodbank_system

--> This project was created for Blood Receivers and Hospitals where a Hospital can add blood samples to their blood bank and blood recievers can request for the blood sample. 

--> Technologies used are: HTML, CSS, Bootstrap, JavaScript as a frontend, PHP as a backend and MySQL for the database.

--> Made with passion by GPW Team